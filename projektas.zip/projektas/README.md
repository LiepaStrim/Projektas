Wrote about my cat
Added a picture of my cat
Wrote some facts about him